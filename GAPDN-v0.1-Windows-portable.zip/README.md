# GAPDN V0.1

A lightweight, offline personal execution monitor. Take a quick check, then return to work.

> The monitoring system should consume far less attention than the behavior it monitors.

## Usage

Double-click `GAPDN.exe`, then select **+ New Check**. Choose a score for all five metrics before saving. Notes are optional. Selected scores have a check mark; hover over an info icon for scoring guidance.

| Metric | 0 | 1 | 2 |
| --- | --- | --- | --- |
| G · Goal | Main goal unclear | Vague or competing goals | One clear main goal |
| A · Alignment | Mostly off target | Some drift | Consistently aligned |
| P · Progress | No meaningful progress | Some progress | Clear, observable progress |
| D · Distraction Control | Pulled into other tasks | Distracted, but recovered | Stayed on track or parked new goals |
| N · Next | Next step unknown | Rough idea of next step | Next important action is clear |

Check Score = sum of the five scores / 10 × 100%. Daily Score is the arithmetic mean of that day's checks, displayed as a whole percentage. No records displays `—`. Scores of 90–100% are green, 60–89% yellow, and below 60% red.

Use the date buttons to browse records. Double-click a record or select **View / Edit** to read notes and edit scores. Editing preserves the original date and time. **Delete** asks for confirmation. New checks use the local date and time when saved. At midnight, the main view advances if it was displaying today.

## Reminders

Settings offers Off (default), every 30 / 45 / 60 minutes, Random 25–45 minutes, and a custom fixed interval of 5–180 whole minutes.

A reminder is a small, silent window. **Check Now** opens a check; saving or canceling schedules the next cycle. **Skip** or closing the reminder schedules the next cycle without creating a record. Random mode draws a fresh interval each cycle. If a check is already open, the reminder waits another interval. Unanswered reminders do not stack. Saving settings immediately resets the timer.

Reminders continue when minimized. Closing the main window exits GAPDN. While the computer sleeps, timers do not run; after resume, the GUI handles an overdue timer without replaying multiple missed reminders.

## Run and Build

Running the source requires Python 3 with Tkinter. No third-party runtime dependencies are needed:

```bat
python gapdn.py
```

Building on Windows requires Python and PyInstaller:

```bat
python -m pip install pyinstaller
build.bat
```

You can also double-click `build.bat`. If PyInstaller is missing, the script attempts to install it (internet access is needed for that installation). Output: `dist\GAPDN.exe`, a single executable without a console window. End users need no Python installation, network connection, or administrator privileges. Place the EXE in a writable folder.

## Local Data and Export

`gapdn_data.json` is stored beside the EXE, or beside `gapdn.py` when running the source. It is created on first launch. Damaged or empty files are preserved as timestamped `gapdn_data_corrupted_*.json` files; the app displays a warning and creates empty data. Saves use a temporary file and atomic replacement. Failed writes are reported. Copy both the EXE and JSON file when moving or backing up the app. Avoid running multiple instances against the same data file.

**Export CSV** exports the displayed date or all dates to a chosen file. Exports include the date, time, all five scores and notes, and check score. UTF-8 with BOM supports international text in Excel. Canceling writes nothing.

Developer verification: run `python -m unittest discover -s tests -v` from the parent project folder. Tests use temporary data outside the release package.
